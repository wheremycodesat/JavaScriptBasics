//Challenge 1: Your age in days

function AgeInDays(){
    let birthYear = document.getElementById('year').value; // .value gets the value we type in the form 
    let birthMonth = document.getElementById('month').value;
    let birthDay = document.getElementById('day').value;

    var birthDate = new Date(birthYear, (birthMonth - 1), birthDay); 
    let currentDate = new Date;

    var diff = currentDate.getTime() - birthDate.getTime();
    var InDays = Math.floor(diff / (1000 * 3600 * 24));
    
    var h1 = document.createElement('h1');
    
    var textDate = birthDate.getDate() + '/' + (birthDate.getMonth() + 1) + '/' + birthDate.getFullYear();
    var textAnswer = document.createTextNode('Oh! You were born on '+ textDate + '. You are ' + InDays + ' days old.');
    h1.setAttribute('id', 'AgeInDays');
    h1.appendChild(textAnswer);
    document.getElementById('flex-box-result').appendChild(h1);
}

function reset(){
    document.getElementById('AgeInDays').remove();
}


//Challenge 2: Car Generator

function generateCat(){
    //Creates an image element
    var image = document.createElement('img');
    //We create a variable to indicate the div we want to work with
    var div = document.getElementById('flex-cat-gen');
    image.src = "https://thecatapi.com/api/images/get?format=src&type=gif&size=small";
    image.width = 200; //We make sure the width is always the same
    image.height = 200; //We make sure the heigth is always the same
    div.appendChild(image);
}



//Challenge 3: Rock, Paper, Scissors

function rpsGame(yourChoice){
    var humanChoice, botChoice;
    humanChoice = yourChoice.id;
    botChoice = numberToChoice(pickRandom());
    results = decideWinner(humanChoice, botChoice);
    message = finalMessage(results);
    rpsFrontEnd(yourChoice.id, botChoice, message);
}

//To make the computer pick a random number between 0 and 2
function pickRandom(){
    return Math.floor(Math.random() * 3);
}

//The computer selects rock, paper or scissors according to the random number
function numberToChoice(number){
    return ['rock', 'paper', 'scissors'][number];
}

//We decide winner based on the score
function decideWinner(humanChoice, botChoice){
    //We create an object were we store the posible outcomes and scores so we don't have to hardcode a lot of if-else statements
    var rpsDataBase ={
        'rock': {'scissors': 1, 'rock': 0.5, 'paper': 0},
        'paper': {'rock': 1, 'paper': 0.5, 'scissors': 0},
        'scissors': {'paper': 1, 'scissors': 0.5, 'rock': 0},
    }


    var yourScore = rpsDataBase[humanChoice][botChoice];
    var computerScore = rpsDataBase[botChoice][humanChoice];

    return [yourScore, computerScore];
}

//Based on our score we give the message that we want, this is pretty simple
function finalMessage([yourScore, computerScore]){
    if (yourScore === 0) {
        return {'message': 'You lost!', 'color': 'red'};
    }else if (yourScore === 0.5){
        return {'message': 'You tied!', 'color': 'yellow'};
    }else {
        return {'message': 'You won!', 'color': 'green'};
    }
}

/*Now this is the real hardcoding part.*/ 
function rpsFrontEnd(humanImageChoice, botImageChoice, finalMessage){
    //We create sort of a database were we put the source of our images based on the key 
    var imagesDataBase = {
        'rock': document.getElementById('rock').src,
        'paper': document.getElementById('paper').src,
        'scissors': document.getElementById('scissors').src,
    }

    //Let's remove all the images
    document.getElementById('rock').remove();
    document.getElementById('paper').remove();
    document.getElementById('scissors').remove();

    //Creating the results on their own divs
    var humanDiv = document.createElement('div');
    var botDiv = document.createElement('div');
    var messageDiv = document.createElement('div');


    /*Form to use Javascript to generate HTML so we don't mess with the index.html*/

    //Human Choice div treatment. We put the HTML code directly and use string concatenation to specify everything
    humanDiv.innerHTML = "<img src='" + imagesDataBase[humanImageChoice] + "' height='150' width='150' style='box-shadow: 0px 10px 50px rgba(37, 50 , 233, 1);'>"

    document.getElementById('flex-box-rps-div').appendChild(humanDiv);


    //Message div treatment. And we must remenber that this is kind of a header
    messageDiv.innerHTML = "<h1 style='color: " + finalMessage['color'] + "; font-size: 60px; padding: 30px; '>" + finalMessage['message'] + "</h1>";

    document.getElementById('flex-box-rps-div').appendChild(messageDiv);


    //Bot Choice div treatment. We put the HTML code directly and use string concatenation to specify everything
    botDiv.innerHTML = "<img src='" + imagesDataBase[botImageChoice] + "' height='150' width='150' style='box-shadow: 0px 10px 50px rgba(243, 38, 24, 1);'>"

    document.getElementById('flex-box-rps-div').appendChild(botDiv);

}



/*Challenge 4: Change the color of all buttons*/

//Collect all of the buttons
var all_buttons = document.getElementsByTagName('button'); //This returns an array with all the buttons 

//To save colors' values when we reset 
var copyAllButtons = [];

for(let i=0; i < all_buttons.length; i++){
    copyAllButtons.push(all_buttons[i].classList[1]);
}

function buttonColorChange(buttonThingy){
    if(buttonThingy.value === 'red'){
        buttonsRed();
    }else if(buttonThingy.value === 'green'){
        buttonsGreen();
    }else if(buttonThingy.value === 'reset'){
        buttonColorReset();
    }else if(buttonThingy.value === 'random'){
        randomColors();
    }
}

//To turn all the buttons red
function buttonsRed(){
    for(let i=0; i < all_buttons.length; i++){
        all_buttons[i].classList.remove(all_buttons[i].classList[1]); //remove the color from all buttons first
        all_buttons[i].classList.add('btn-danger'); //Then we want to immediately add the color
    }
}

//To turn all the buttons green
function buttonsGreen(){
    for(let i = 0; i < all_buttons.length; i++){
        all_buttons[i].classList.remove(all_buttons[i].classList[1]); //remove the color from all buttons first
        all_buttons[i].classList.add('btn-success'); //Then we want to immediately add the color
    }
}

//To reset the buttons to their original colors 
function buttonColorReset(){
    for(let i= 0; i < all_buttons.length; i++){
        all_buttons[i].classList.remove(all_buttons[i].classList[1]); //remove the color from all buttons first
        all_buttons[i].classList.add(copyAllButtons[i]); //then we want to loop through the array of the copies we saved and add them to the buttons
    }
}

/*For the random function i used two functions:
    pickRandomNumber()
    colorOfChoice(color)

  Or we can code it in just one function:

    let choices = ['btn-primary','btn-danger','btn-success','btn-warning'];

    for(let i = 0; i < all_buttons.length; i++){
        let randomNumber = Math.floor(Math.random() * 4);

        all_buttons[i].classList.remove(all_buttons[i].classList[1]); //remove the color from all buttons first
        all_buttons[i].classList.add(choices[randomNumber]); //then add immediately random colors
    }

*/

function pickRandomColor(){
    return Math.floor(Math.random() * 4);
}

function colorOfChoice(color){
    return ['btn-primary','btn-danger','btn-success','btn-warning'][color];
}

//To change the colors randomly
function randomColors(){
    for(let i = 0; i < all_buttons.length; i++){
        all_buttons[i].classList.remove(all_buttons[i].classList[1]); ////remove the color from all buttons first
        all_buttons[i].classList.add(colorOfChoice(pickRandomColor()));
    }
}



/*Challenge 5: Blackjack */

//We create an object for the game (very useful)
let blackjackGame = {
    'you': {'scoreSpan': '#your-blackjack-result', 'div': '#your-box', 'score' : 0},
    'dealer': {'scoreSpan': '#dealer-blackjack-result', 'div': '#dealer-box', 'score' : 0},
    'cards' : ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'],
    'cardsMap': {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'J': 10, 'Q': 10, 'K': 10, 'A': [1, 11]},
    'wins': 0,
    'losses': 0,
    'draws': 0,
    'isStand': false,
    'turnsOver': false,
};

const YOU = blackjackGame['you'];
const DEALER = blackjackGame['dealer'];

const hitSound = new Audio('static/sounds/swish.m4a');
const winSound = new Audio('static/sounds/cash.mp3');
const lossSound = new Audio('static/sounds/aww.mp3');
const drewSound = new Audio('static/sounds/reallyN.mp3');

//Nice way to do things with elements without using .getElement and onclick/onchange on our html
document.querySelector('#hit-button').addEventListener('click', blackjackHit);
document.querySelector('#deal-button').addEventListener('click', blackjackDeal);
document.querySelector('#stand-button').addEventListener('click', dealerLogic);

//Main function for the hit button
function blackjackHit(){
    if(blackjackGame['isStand'] === false){
        let card = randomCard();
        showCard(card, YOU);
        updateScore(card, YOU);
        showScore(YOU);
    }
}

//We declare an sleep function to make our serving 1 second (1000ms) long
function sleep(ms){
    return new Promise(resolve => setTimeout(resolve, ms));
}

//Function for the stand button
//We have to put the reserved word 'async' so the code doesn't run linearly. This means that every second the computer is waiting the browser will be frozen... We cannot scroll, hover over, etc...
async function dealerLogic(){
    blackjackGame['isStand'] = true; //As soon as we hit the stand button we cannot click hit again

    while(DEALER['score'] < 16 && blackjackGame['isStand'] === true){
        let card = randomCard();
        showCard(card, DEALER);
        updateScore(card, DEALER);
        showScore(DEALER);
        await sleep(1000);
    }
    
    blackjackGame['turnsOver'] = true;
    let winner = computeWinner();
    showResult(winner);
}

function showCard(card, activePlayer){
    if(activePlayer['score'] <= 21){
        let cardImage = document.createElement('img');
        cardImage.src = `static/images/${card}.png`; //String templating
        document.querySelector(activePlayer['div']).appendChild(cardImage);
        hitSound.play();
    }
}

//to remove all the cards and to reset everything when we hit deal
function blackjackDeal(){
    //We can only click 'deal' when the game is over
    if(blackjackGame['turnsOver'] === true){

        let yourImages = document.querySelector('#your-box').querySelectorAll('img'); //This returns an array with all the images
        let dealerImages = document.querySelector('#dealer-box').querySelectorAll('img');
        
        //Removing all the cards
        for(let i = 0; i < yourImages.length; i++){
            yourImages[i].remove();
        }

        for(let i = 0; i < dealerImages.length; i++){
            dealerImages[i].remove();
        }

        //RESET all the other things

        //Reset the scores internally
        YOU['score'] = 0;
        DEALER['score'] = 0;

        //Setting the scores to 0 in the front-end
        document.querySelector('#your-blackjack-result').textContent = 0;
        document.querySelector('#dealer-blackjack-result').textContent = 0;
        
        //Setting the colors to white again
        document.querySelector('#your-blackjack-result').style.color = 'white';
        document.querySelector('#dealer-blackjack-result').style.color = 'white';

        //Setting the header "Let's play" back to its original form
        document.querySelector('#blackjack-result').textContent = "Let's play";
        document.querySelector('#blackjack-result').style.color = "black";

        //Setting our booleans to their original state
        blackjackGame['isStand'] = false;
        blackjackGame['turnsOver'] = false;
    }
}

function randomCard(){
    let randomIndex = Math.floor(Math.random() * 13);
    return blackjackGame['cards'][randomIndex];
}

function updateScore(card, activePlayer){

    if(card === 'A'){
         //If adding 11 keeps me below 21, add 11.Otherwise, add 1
        if(activePlayer['score'] + blackjackGame['cardsMap'][card][1] <= 21){
            activePlayer['score'] += blackjackGame['cardsMap'][card][1];
        }else{
            activePlayer['score'] += blackjackGame['cardsMap'][card][0];
        }

    }else{
        activePlayer['score'] += blackjackGame['cardsMap'][card];
    }
}

function showScore(activePlayer){
    if(activePlayer['score'] > 21){
        document.querySelector(activePlayer['scoreSpan']).textContent = 'BUST!';
        document.querySelector(activePlayer['scoreSpan']).style.color = 'red';
    }else{
        document.querySelector(activePlayer['scoreSpan']).textContent = activePlayer['score'];
    }
}

// Compute winner and return who just won
// update the wins, draws, and losses
function computeWinner(){
    let winner;

    if(YOU['score'] <= 21){
        // condition: higher score than dealer or when dealer busts but you're 21 or under
        if((YOU['score'] > DEALER['score']) || (DEALER['score'] > 21)){
            blackjackGame['wins']++;
            winner = YOU;

        }else if(YOU['score'] < DEALER['score']){
            blackjackGame['losses']++;
            winner = DEALER;

        } else if(YOU['score'] === DEALER['score']){
            blackjackGame['draws']++;
        }

    // condition: when user bust but dealer doesn't
    } else if(YOU['score'] > 21 && DEALER['score'] <= 21){ 
        blackjackGame['losses']++;
        winner = DEALER;

    // condition: when you and the dealer bust
    }else if(YOU['score'] > 21 && DEALER['score'] > 21){
        blackjackGame['draws']++;
    }

    return winner;
}

function showResult(winner){
    let message, messageColor;

    if(blackjackGame['turnsOver'] === true){

        if(winner === YOU){
            //To show the wins on the table
            document.querySelector('#wins').textContent = blackjackGame['wins'];
            message = 'You won!';
            messageColor = 'green';
            winSound.play();
        }else if(winner === DEALER){
            //To show the losses on the table
            document.querySelector('#losses').textContent = blackjackGame['losses'];
            message = 'You lost!';
            messageColor = 'red';
            lossSound.play();
        }else{
            //To show the draws on the table
            document.querySelector('#draws').textContent = blackjackGame['draws'];
            message = 'You drew!';
            messageColor = 'black';
            drewSound.play();
        }

        document.querySelector('#blackjack-result').textContent = message;
        document.querySelector('#blackjack-result').style.color = messageColor;
    }
}

